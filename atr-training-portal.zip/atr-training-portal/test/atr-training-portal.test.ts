// import * as cdk from 'aws-cdk-lib';
// import { Template } from 'aws-cdk-lib/assertions';
// import * as AtrTrainingPortal from '../lib/atr-training-portal-stack';

// example test. To run these tests, uncomment this file along with the
// example resource in lib/atr-training-portal-stack.ts
test('SQS Queue Created', () => {
//   const app = new cdk.App();
//     // WHEN
//   const stack = new AtrTrainingPortal.AtrTrainingPortalStack(app, 'MyTestStack');
//     // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
});
